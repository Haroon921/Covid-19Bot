using System;
using System.Collections.Generic;

namespace Microsoft.BotBuilderSamples
{
    public class CountryCode
    {

    public string CodeRead(String code, string currentLang)
    {
        Dictionary<string, string> dict = new Dictionary<string, string>();
        if(currentLang == "ar")
        { 
            dict.Add("SA", "المملكة العربية السعودية");
            dict.Add("AE", "الإمارات العربية المتحدة");
            dict.Add("IN", "الهند");
            dict.Add("PK", "باكستان");
            dict.Add("BD", "بنغلاديش");
            dict.Add("JO", "الأردن");
            dict.Add("OM", "عُمان");
            dict.Add("TR", "تركيا");
            dict.Add("BH", "البحرين");
            dict.Add("US", "الولايات المتحدة الأمريكية");
            dict.Add("ES", "إسبانيا");
            dict.Add("IT", "إيطاليا");
        }
        else{
                dict.Add("SA", "Saudi Arabia");
                dict.Add("AE", "United Arab Emirates");
                dict.Add("IN", "India");
                dict.Add("PK", "pakistan");
                dict.Add("BD", "bangladesh");
                dict.Add("JO", "Jordan");
                dict.Add("OM", "Oman");
                dict.Add("TR", "Turkey");
                dict.Add("BH", "Bahrain");
                dict.Add("US", "United States of America");
                dict.Add("ES", "Spain");
                dict.Add("IT", "Italy");
        }
            var CountryName = dict[code];
            return CountryName;
    }
    }
}
