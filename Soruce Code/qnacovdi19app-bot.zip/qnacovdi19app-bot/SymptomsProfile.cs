namespace Microsoft.BotBuilderSamples
{
    public class SymptomsProfile
    {
        public string AgeDetect { get; set; }
        public string CovidSymptomsDetect { get; set; }

        public string OthersSymptomsDetect { get; set; }

        public string TravelInternational { get; set; }

        public string ContactWithPerson { get; set; }

        public string LiveInWideSpread { get; set; }

        public string LiveInNurseHome { get; set; }

        public string PlanVolunteer { get; set; }

        public string Conditions { get; set; }

        public string FinalMessage { get; set; }
    }
}