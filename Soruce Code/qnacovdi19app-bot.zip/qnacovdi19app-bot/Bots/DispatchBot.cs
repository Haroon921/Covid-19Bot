using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Microsoft.BotBuilderSamples {
    public class DispatchBot : ActivityHandler {

        //private readonly BotServices _translator;
        private readonly ILogger<DispatchBot> _logger;
        private readonly IBotServices _botServices;

        private static readonly HttpClient client = new HttpClient ();

        private readonly string[] _cards = {
            Path.Combine (".", "cards", "Covid19Status.json"),
            Path.Combine (".", "cards", "GlobalStatus.json"),
            Path.Combine (".", "cards", "Covid19Status_AR.json"),
            Path.Combine (".", "cards", "GlobalStatus_AR.json"),
        };

        private const string EnglishEnglish = "en";
        private const string EnglishArabic = "ar";
        private readonly UserState _userState;
        //private readonly ConversationState _conversationState;
        private readonly BotState _conversationState;
        private readonly IStatePropertyAccessor<string> _languagePreference;

        private readonly IStatePropertyAccessor<ConversationFlow> _conversationStateAccessors;

        private readonly IStatePropertyAccessor<SymptomsProfile> _userStateAccessors;

        private readonly IStatePropertyAccessor<string> _SymptomsScreeningStage;

        private readonly IStatePropertyAccessor<int> _AgeDetect;

        private readonly IStatePropertyAccessor<string> _CovidSymptomsDetect;

        private readonly IStatePropertyAccessor<string> _OthersSymptomsDetect;
        public DispatchBot (IBotServices botServices, ILogger<DispatchBot> logger, UserState userState, ConversationState conversationState) {
            _logger = logger;
            _botServices = botServices;

            _userState = userState ??
                throw new NullReferenceException (nameof (userState));

            _conversationState = conversationState ??
                throw new NullReferenceException (nameof (conversationState));

            _languagePreference = userState.CreateProperty<string> ("LanguagePreference");

            _SymptomsScreeningStage = userState.CreateProperty<string> ("SymptomsScreeningStage");

            _AgeDetect = userState.CreateProperty<int> ("AgeDetect");

            _CovidSymptomsDetect = userState.CreateProperty<string> ("CovidSymptomsDetect");

            _OthersSymptomsDetect = userState.CreateProperty<string> ("OthersSymptomsDetect");

            _conversationStateAccessors = _conversationState.CreateProperty<ConversationFlow> (nameof (ConversationFlow));

            _userStateAccessors = _userState.CreateProperty<SymptomsProfile> (nameof (SymptomsProfile));
        }

        protected override async Task OnMessageActivityAsync (ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken) {

            var flow = await _conversationStateAccessors.GetAsync (turnContext, () => new ConversationFlow (), cancellationToken);
            var profile = await _userStateAccessors.GetAsync (turnContext, () => new SymptomsProfile (), cancellationToken);
            var lastQuesAsk = flow.LastQuestionAsked.ToString();
            string SymptomsScreeningStage = await _SymptomsScreeningStage.GetAsync (turnContext);
            const string WelcomeText = "Type like a  'ksa' or 'uae' or 'global'\n\n what is coronavirus? for more details. \n\n 'screening'";
            string userLanguage = await _languagePreference.GetAsync (turnContext, () => TranslationSettings.DefaultLanguage) ?? TranslationSettings.DefaultLanguage;
            if (IsLanguageChangeRequested (turnContext.Activity.Text, userLanguage) && (lastQuesAsk =="None")) {
                if (turnContext.Activity.Text != "start") {
                    var selectlang = "";
                    if (turnContext.Activity.Text.ToLower () == "ar" || turnContext.Activity.Text.ToLower () == "en") {
                        selectlang = turnContext.Activity.Text.ToLower ();
                    } else if (turnContext.Activity.Text.ToLower () == "in") {
                        selectlang = "en";
                    }
                    var currentLang = selectlang;
                    var lang = currentLang == EnglishEnglish ? EnglishEnglish : EnglishArabic;
                    await _languagePreference.SetAsync (turnContext, lang, cancellationToken);

                    // Save the user profile updates into the user state.
                    await _userState.SaveChangesAsync (turnContext, false, cancellationToken);

                    var selectedLang = currentLang == EnglishEnglish ? "English" : "Arabic";
                    var reply = ((Activity) turnContext.Activity).CreateReply ($"Your current language is: " + selectedLang);

                    await turnContext.SendActivityAsync (reply, cancellationToken);
                    await turnContext.SendActivityAsync (MessageFactory.Text ($"Welcome to Covid19Bot. {WelcomeText}"), cancellationToken);
                } else {
                    var reply = ((Activity) turnContext.Activity).CreateReply ("Choose your language:");
                    reply.SuggestedActions = new SuggestedActions () {
                        Actions = new List<CardAction> () {
                        /// new CardAction () { Title = "Español", Type = ActionTypes.PostBack, Value = EnglishSpanish },
                        new CardAction () { Title = "English", Type = ActionTypes.PostBack, Value = EnglishEnglish },
                        new CardAction () { Title = "العربية", Type = ActionTypes.PostBack, Value = EnglishArabic },

                        },
                    };
                    await turnContext.SendActivityAsync (reply, cancellationToken);

                }
            } else
            if (SymptomsScreeningStage == "Covid19ScreeningStage") {

                await FillOutCovidAsync (flow, profile, turnContext, cancellationToken);
                // Save changes.
                await _conversationState.SaveChangesAsync (turnContext, false, cancellationToken);
                await _userState.SaveChangesAsync (turnContext, false, cancellationToken);

            } else {
                // First, we use the dispatch model to determine which cognitive service (LUIS or QnA) to use.
                var recognizerResult = await _botServices.Dispatch.RecognizeAsync (turnContext, cancellationToken);
                // Top intent tell us which cognitive service to use.
                var topIntent = recognizerResult.GetTopScoringIntent ();

                // Next, we call the dispatcher with the top intent.
                await DispatchToTopIntentAsync (turnContext, topIntent.intent, recognizerResult, cancellationToken);
            }
        }

        protected override async Task OnMembersAddedAsync (IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken) {
            foreach (var member in membersAdded) {
                if (member.Id != turnContext.Activity.Recipient.Id) {

                    var reply = ((Activity) turnContext.Activity).CreateReply ("Choose your language:");
                    reply.SuggestedActions = new SuggestedActions () {
                        Actions = new List<CardAction> () {
                        /// new CardAction () { Title = "Español", Type = ActionTypes.PostBack, Value = EnglishSpanish },
                        new CardAction () { Title = "English", Type = ActionTypes.PostBack, Value = EnglishEnglish },
                        new CardAction () { Title = "العربية", Type = ActionTypes.PostBack, Value = EnglishArabic },

                        },
                    };
                    await turnContext.SendActivityAsync (reply, cancellationToken);

                }
            }
        }

        private async Task DispatchToTopIntentAsync (ITurnContext<IMessageActivity> turnContext, string intent, RecognizerResult recognizerResult, CancellationToken cancellationToken) {
            switch (intent) {

                case "l_covid19":
                    await ProcessCovid19LuisAsync (turnContext, recognizerResult.Properties["luisResult"] as LuisResult, cancellationToken);
                    break;
                case "q_covid19":
                    await ProcessSampleQnAAsync (turnContext, cancellationToken);
                    break;
                default:
                    _logger.LogInformation ($"Covid19Bot unrecognized you.");
                    await turnContext.SendActivityAsync (MessageFactory.Text ($"Covid19Bot unrecognized you, kindly type a question as what is the symptoms of covid19."), cancellationToken);
                    break;
            }
        }

        private async Task ProcessCovid19LuisAsync (ITurnContext<IMessageActivity> turnContext, LuisResult luisResult, CancellationToken cancellationToken) {
            _logger.LogInformation ("ProcessCovid19LuisAsync");

            string userLanguage = await _languagePreference.GetAsync (turnContext, () => TranslationSettings.DefaultLanguage) ?? TranslationSettings.DefaultLanguage;
            CountryCode obj = new CountryCode ();

            // Retrieve LUIS result for Process Automation.
            var result = luisResult.ConnectedServiceResult;
            var topIntent = result.TopScoringIntent.Intent;
            var text = turnContext.Activity.Text.Trim ().ToLower ();
            if (text == "screening") {
                topIntent = "Covid19Screening";
            }
            DateTime thisDay = DateTime.Today;
            var fromDate = thisDay.AddDays (-7).ToString ("yyyy-MM-dd");
            var toDate = thisDay.ToString ("yyyy-MM-dd"); //{30/06/2020 12:00:00 AM} //dd MMM yyyy
            if ((topIntent != "None") && (topIntent != "Covid19Global") && (topIntent != "Covid19Screening")) {
                var IntentCountryCode = topIntent.Substring (topIntent.Length - 2);
                var CountryName = obj.CodeRead (IntentCountryCode, userLanguage);
                //== "Covid19KSA"
                //  "https://api.covid19api.com/country/sa?from=2020-06-23T00:00:00Z&to=2020-06-30T00:00:00Z";
                //var url = $"https://api.covid19api.com/total/country/" + IntentCountryCode;
                var url = "https://api.covid19api.com/country/" + IntentCountryCode + "?from=" + fromDate + "&to=" + toDate;
                var repositories = ProcessRepo (url);
                List<string> Ystdata = new List<string> ();
                List<string> Tdydata = new List<string> ();

                if (repositories.Count > 0) {
                    var ystData = repositories[repositories.Count - 2];
                    var todayData = repositories.LastOrDefault ();
                    //DateTime thisDay = DateTime.Today;
                    // DateTime Todaydatetime = DateTime.Parse (todayData.date);
                    DateTime LastupdtDt = DateTime.Parse (todayData.date);
                    DateTime Ystdatetime = DateTime.Parse (ystData.date);

                    var confirmedInc = todayData.confirmed - ystData.confirmed;
                    var confirmedIncPCT = (((Math.Abs (Convert.ToDecimal (confirmedInc))) / (Math.Abs (Convert.ToDecimal (todayData.confirmed)))) * 100).ToString ("0.00");

                    var activeInc = todayData.active - ystData.active;
                    var activeIncPCT = (((Math.Abs (Convert.ToDecimal (activeInc))) / (Math.Abs (Convert.ToDecimal (todayData.active)))) * 100).ToString ("0.00"); //(activeInc / todayData.active) * 100;

                    var recoveredInc = todayData.recovered - ystData.recovered;
                    var recoveredIncPCT = (((Math.Abs (Convert.ToDecimal (recoveredInc))) / (Math.Abs (Convert.ToDecimal (todayData.recovered)))) * 100).ToString ("0.00"); //(recoveredInc / todayData.recovered) * 100;

                    var deceasedInc = todayData.deaths - ystData.deaths;
                    var deceasedIncPCT = (((Math.Abs (Convert.ToDecimal (deceasedInc))) / (Math.Abs (Convert.ToDecimal (todayData.deaths)))) * 100).ToString ("0.00"); //(deceasedInc / todayData.deaths) * 100;

                    Ystdata.Add (ystData.confirmed.ToString ());
                    Ystdata.Add (ystData.deaths.ToString ());
                    Ystdata.Add (ystData.recovered.ToString ());
                    Ystdata.Add (ystData.active.ToString ());
                    Ystdata.Add (Ystdatetime.ToString ("dd MMM yyyy"));

                    Tdydata.Add (todayData.confirmed.ToString ());
                    Tdydata.Add (todayData.deaths.ToString ());
                    Tdydata.Add (todayData.recovered.ToString ());
                    Tdydata.Add (todayData.active.ToString ());
                    Tdydata.Add (thisDay.ToString ("dd MMM yyyy") + " " + CountryName); //dict[IntentCountryCode]);
                    Tdydata.Add ("▲ " + " " + confirmedInc + " " + "(" + confirmedIncPCT + " " + "%" + ")");
                    Tdydata.Add ("▲ " + " " + activeInc + " " + "(" + activeIncPCT + " " + "%" + ")");
                    Tdydata.Add ("▲ " + " " + recoveredInc + " " + "(" + recoveredIncPCT + " " + "%" + ")");
                    Tdydata.Add ("▲ " + " " + deceasedInc + " " + "(" + deceasedIncPCT + " " + "%" + ")");
                    var lastupd_text = userLanguage == "en" ? "Last updated by " + LastupdtDt.ToString ("dd MMM yyyy") : LastupdtDt.ToString ("dd MMM yyyy") + " آخر تحديث ";
                    Tdydata.Add (lastupd_text); //Last updated by 
                }
                var card_ind = userLanguage == "en" ? 0 : 2;
                var Covid19StatusCardRead = readFileforUpdate_jobj (_cards[card_ind]);

                JToken Date = Covid19StatusCardRead.SelectToken ("body[0].items[3].text");
                JToken LastUpdateDate = Covid19StatusCardRead.SelectToken ("body[0].items[4].text");
                JToken ConfirmedInc = Covid19StatusCardRead.SelectToken ("body[0].items[5].columns[0].items[1].text");
                JToken Confirmed = Covid19StatusCardRead.SelectToken ("body[0].items[5].columns[0].items[2].text");

                JToken ActiveInc = Covid19StatusCardRead.SelectToken ("body[0].items[5].columns[1].items[1].text");
                JToken Active = Covid19StatusCardRead.SelectToken ("body[0].items[5].columns[1].items[2].text");

                JToken RecoveredInc = Covid19StatusCardRead.SelectToken ("body[0].items[5].columns[2].items[1].text");
                JToken Recovered = Covid19StatusCardRead.SelectToken ("body[0].items[5].columns[2].items[2].text");

                JToken DeceasedInc = Covid19StatusCardRead.SelectToken ("body[0].items[5].columns[3].items[1].text");
                JToken Deceased = Covid19StatusCardRead.SelectToken ("body[0].items[5].columns[3].items[2].text");
                JToken FlagURL = Covid19StatusCardRead.SelectToken ("body[0].items[2].url");

                Date.Replace (Tdydata[4]);
                Confirmed.Replace (Tdydata[0]);
                Active.Replace (Tdydata[3]);
                Recovered.Replace (Tdydata[2]);
                Deceased.Replace (Tdydata[1]);

                ConfirmedInc.Replace (Tdydata[5]);
                ActiveInc.Replace (Tdydata[6]);
                RecoveredInc.Replace (Tdydata[7]);
                DeceasedInc.Replace (Tdydata[8]);

                LastUpdateDate.Replace (Tdydata[9]);
                //FlagURL.Replace ("http://localhost:3978/image/" + IntentCountryCode + ".png");

                FlagURL.Replace ("https://qnacovdi19app-bot.azurewebsites.net/image/" + IntentCountryCode + ".png");
                var Covid19StatusCardFinal = UpdateAdaptivecardAttachment (Covid19StatusCardRead);
                var response = MessageFactory.Attachment (Covid19StatusCardFinal, ssml: "Covid19 Live status card!");
                await turnContext.SendActivityAsync (response, cancellationToken);
            } else
            if ((topIntent == "Covid19Global") && (topIntent != "Covid19Screening")) {
                var url = $"https://api.covid19api.com/summary";
                var repositories = ProcessRepoWorldJ (url);
                List<string> Tdydata = new List<string> ();

                var TotalConfirmed = (string) repositories.SelectToken ("Global.TotalConfirmed");
                var NewConfirmed = (string) repositories.SelectToken ("Global.NewConfirmed");
                var TotalDeaths = (string) repositories.SelectToken ("Global.TotalDeaths");
                var NewDeaths = (string) repositories.SelectToken ("Global.NewDeaths");
                var TotalRecovered = (string) repositories.SelectToken ("Global.TotalRecovered");
                var NewRecovered = (string) repositories.SelectToken ("Global.NewRecovered");
                //var date = (DateTime) repositories.SelectToken ("Date");
                var lastupdatedate = (DateTime) repositories.SelectToken ("Date");
                //var a=_userState.GetAsync(_languagePreference);
                var globalName = userLanguage == "en" ? "Global " : " العالميه ";
                var Todaydatetime = thisDay.ToString ("dd MMM yyyy") + globalName;
                var lastupd_text = userLanguage == "en" ? "Last updated by " + lastupdatedate.ToString ("dd MMM yyyy") : lastupdatedate.ToString ("dd MMM yyyy") + " آخر تحديث من قبل ";
                var lastupdatedon = lastupd_text; //+ lastupdatedate.ToString ("dd MMM yyyy"); // 
                var confirmedIncPCT = (((Math.Abs (Convert.ToDecimal (NewConfirmed))) / (Math.Abs (Convert.ToDecimal (TotalConfirmed)))) * 100).ToString ("0.00");
                var recoveredIncPCT = (((Math.Abs (Convert.ToDecimal (NewRecovered))) / (Math.Abs (Convert.ToDecimal (TotalRecovered)))) * 100).ToString ("0.00");
                var deathsIncPCT = (((Math.Abs (Convert.ToDecimal (NewDeaths))) / (Math.Abs (Convert.ToDecimal (TotalDeaths)))) * 100).ToString ("0.00");

                var confirmIncFinal = "▲ " + " " + NewConfirmed + " " + "(" + confirmedIncPCT + " " + "%" + ")";
                var recoveredFinal = "▲ " + " " + NewRecovered + " " + "(" + recoveredIncPCT + " " + "%" + ")";
                var deathsIncFinal = "▲ " + " " + NewDeaths + " " + "(" + deathsIncPCT + " " + "%" + ")";

                var card_ind = userLanguage == "en" ? 1 : 3;
                var GlobalStatusCardRead = readFileforUpdate_jobj (_cards[card_ind]);

                JToken Date = GlobalStatusCardRead.SelectToken ("body[0].items[3].text");
                JToken lastupdate = GlobalStatusCardRead.SelectToken ("body[0].items[4].text");
                JToken ConfirmedInc = GlobalStatusCardRead.SelectToken ("body[0].items[5].columns[0].items[1].text");
                JToken Confirmed = GlobalStatusCardRead.SelectToken ("body[0].items[5].columns[0].items[2].text");

                JToken RecoveredInc = GlobalStatusCardRead.SelectToken ("body[0].items[5].columns[1].items[1].text");
                JToken Recovered = GlobalStatusCardRead.SelectToken ("body[0].items[5].columns[1].items[2].text");

                JToken DeceasedInc = GlobalStatusCardRead.SelectToken ("body[0].items[5].columns[2].items[1].text");
                JToken Deceased = GlobalStatusCardRead.SelectToken ("body[0].items[5].columns[2].items[2].text");

                Date.Replace (Todaydatetime);
                lastupdate.Replace (lastupdatedon);
                ConfirmedInc.Replace (confirmIncFinal);
                Confirmed.Replace (TotalConfirmed);
                RecoveredInc.Replace (recoveredFinal);
                Recovered.Replace (TotalRecovered);
                DeceasedInc.Replace (deathsIncFinal);
                Deceased.Replace (TotalDeaths);
                //var GlobalStatusCardFinal = CreateAdaptiveCardAttachment(_cards[1]);
                var GlobalStatusCardFinal = UpdateAdaptivecardAttachment (GlobalStatusCardRead);
                var response = MessageFactory.Attachment (GlobalStatusCardFinal, ssml: "Global Live status card!");
                await turnContext.SendActivityAsync (response, cancellationToken);
            } else
            if ((topIntent == "Covid19Screening" && topIntent != "Covid19Global") || text == "screening") {
                await turnContext.SendActivityAsync (MessageFactory.Text ($"Hi, I’m here to guide you through the Coronavirus Self-Assessment Tool.\n\n Disclaimer, must be over 18. \n\n" +
                    "Call the number for your local emergency service.\n\n if you have any extreme or life threatening symptoms including constant chest pain or pressure, extreme difficulty a breathing or severe shortness of breath severe constant dizziness or lightheadedness, slurred speech, or difficulty waking up."), cancellationToken);

                await _SymptomsScreeningStage.SetAsync (turnContext, "Covid19ScreeningStage", cancellationToken);
                await _userState.SaveChangesAsync (turnContext, false, cancellationToken);

                var flow = await _conversationStateAccessors.GetAsync (turnContext, () => new ConversationFlow (), cancellationToken);
                var profile = await _userStateAccessors.GetAsync (turnContext, () => new SymptomsProfile (), cancellationToken);

                await FillOutCovidAsync (flow, profile, turnContext, cancellationToken);
                // Save changes.
                await _conversationState.SaveChangesAsync (turnContext, false, cancellationToken);
                await _userState.SaveChangesAsync (turnContext, false, cancellationToken);
            } else {
                _logger.LogInformation ($"Luis unrecognized intent.");
                await turnContext.SendActivityAsync (MessageFactory.Text ($"Covid19Bot unrecognized your inputs, kindly reply as 'live covid19 status'."), cancellationToken);
            }
        }

        private async Task ProcessSampleQnAAsync (ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken) {
            _logger.LogInformation ("ProcessSampleQnAAsync");

            var results = await _botServices.SampleQnA.GetAnswersAsync (turnContext);
            if (results.Any ()) {
                await turnContext.SendActivityAsync (MessageFactory.Text (results.First ().Answer), cancellationToken);
            } else {
                await turnContext.SendActivityAsync (MessageFactory.Text ("Sorry, could not find an answer in the Q and A, kindly type a question as 'what is the symptoms of covid19'."), cancellationToken);
            }
        }

        private static Attachment CreateAdaptiveCardAttachment (string filePath) {
            var adaptiveCardJson = File.ReadAllText (filePath);
            var adaptiveCardAttachment = new Attachment () {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject (adaptiveCardJson),
            };
            return adaptiveCardAttachment;
        }

        private static JObject readFileforUpdate_jobj (string filepath) {
            var json = File.ReadAllText (filepath);
            var jobj = JsonConvert.DeserializeObject (json);
            JObject Jobj_card = JObject.FromObject (jobj) as JObject;
            return Jobj_card;
        }

        private static Attachment UpdateAdaptivecardAttachment (JObject updateAttch) {
            var adaptiveCardAttch = new Attachment () {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject (updateAttch.ToString ()),
            };
            return adaptiveCardAttch;
        }

        private static List<Repo> ProcessRepo (string Url) {
            var webRequest = WebRequest.Create (Url) as HttpWebRequest;
            List<Repo> repositories = new List<Repo> ();
            webRequest.ContentType = "application/json";
            webRequest.UserAgent = "User-Agent";
            using (var s = webRequest.GetResponse ().GetResponseStream ()) {
                using (var sr = new StreamReader (s)) {
                    var contributorsAsJson = sr.ReadToEnd ();
                    repositories = JsonConvert.DeserializeObject<List<Repo>> (contributorsAsJson);
                }
            }
            return repositories;
        }

        private static JObject ProcessRepoWorldJ (string Url) {
            var webRequest = WebRequest.Create (Url) as HttpWebRequest;
            JObject repositories = new JObject ();
            webRequest.ContentType = "application/json";
            webRequest.UserAgent = "User-Agent";
            using (var s = webRequest.GetResponse ().GetResponseStream ()) {
                using (var sr = new StreamReader (s)) {
                    var contributorsAsJson = sr.ReadToEnd ();
                    var jobj = JsonConvert.DeserializeObject (contributorsAsJson);
                    JObject Jobj_card = JObject.FromObject (jobj) as JObject;

                    repositories = JObject.Parse (contributorsAsJson);
                }
            }
            return repositories;
        }

        private static bool IsLanguageChangeRequested (string utterance, string lang) {
            if (string.IsNullOrEmpty (utterance)) {
                return false;
            }
            utterance = utterance.ToLower ().Trim ();
            if (lang == "ar" && utterance == "in") {
                utterance = EnglishEnglish;
            }

            return utterance == EnglishArabic || utterance == EnglishEnglish || utterance == "start";
        }

        private async Task FillOutCovidAsync (ConversationFlow flow, SymptomsProfile profile, ITurnContext turnContext, CancellationToken cancellationToken) {
            var Msg1 = "Testing is not recommended at this time";
            var Msg2 = "Contact your provider if symptoms worsen";
            var Msg3 = "Contact your healthcare provider, testing may be recommended";
            // var Msg4 ="Testing recommended";
            // var Msg5 ="Contact your occupational health";
            // var Msg6 ="Contact your facility";
            // var Msg7 ="Contact your provider if symptoms worsen";
            var Msg8 = "Self isolate";
            var initialMsg = "As per your screening, Bot suggested you to take the following precautions";
            var age_detect = await _AgeDetect.GetAsync (turnContext);
            var covidSymDetect = await _CovidSymptomsDetect.GetAsync (turnContext);
            var otherSymDetect = await _OthersSymptomsDetect.GetAsync (turnContext);

            var input = turnContext.Activity.Text?.Trim ();
            string message;

            switch (flow.LastQuestionAsked) {

                case ConversationFlow.Question.None:
                    var msg = "What is your age?";

                    await turnContext.SendActivityAsync (msg, null, null, cancellationToken);
                    flow.LastQuestionAsked = ConversationFlow.Question.AgeDetect;
                    break;
                case ConversationFlow.Question.AgeDetect:

                    if (ValidateAge (input, out var textA, out message)) {
                        if (textA >= 18) {
                            await _AgeDetect.SetAsync (turnContext, textA, cancellationToken);
                            await _userState.SaveChangesAsync (turnContext, false, cancellationToken);

                            profile.AgeDetect = textA.ToString ();
                            var msgCovid = "Are you experiencing any of these Covid symptoms? \n\n" +
                                "\t • Fever or feeling feverish (chills, sweating)\n\n" +
                                "\t • Difficulty breathing (not severe)\n\n" +
                                "\t • New or worsening cough\n\n";
                            await turnContext.SendActivityAsync (msgCovid, null, null, cancellationToken);
                            flow.LastQuestionAsked = ConversationFlow.Question.CovidSymptomsDetect;
                            break;
                        }
                        if (textA < 18) {
                            await turnContext.SendActivityAsync ("This is intended only for people who are age ≥18 years", null, null, cancellationToken);
                            break;
                        }
                        break;
                    } else {
                        await turnContext.SendActivityAsync (message, null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.AgeDetect;
                        break;
                    }

                case ConversationFlow.Question.CovidSymptomsDetect:
                    if (ValidateYes (input, out var textC, out message)) {
                        if (input == "yes") {
                            await _CovidSymptomsDetect.SetAsync (turnContext, "true", cancellationToken);
                            await _userState.SaveChangesAsync (turnContext, false, cancellationToken);
                        } else if (input == "no") {
                            await _CovidSymptomsDetect.SetAsync (turnContext, "false", cancellationToken);
                            await _userState.SaveChangesAsync (turnContext, false, cancellationToken);
                        }
                        profile.CovidSymptomsDetect = textC;
                        var msgOthers = "Are you experiencing any of these others symptoms? \n\n" +
                            "\t • Sore throat\n\n" +
                            "\t • Whole body aches\n\n" +
                            "\t • Vomiting or diarrhea\n\n";
                        await turnContext.SendActivityAsync (msgOthers, null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.OthersSymptomsDetect;
                        break;
                    } else {
                        await turnContext.SendActivityAsync (message, null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.CovidSymptomsDetect;
                        break;
                    }
                case ConversationFlow.Question.OthersSymptomsDetect:
                    if (ValidateYes (input, out var textO, out message)) {
                        if (input == "yes") {
                            await _OthersSymptomsDetect.SetAsync (turnContext, "true", cancellationToken);
                            await _userState.SaveChangesAsync (turnContext, false, cancellationToken);
                        } else if (input == "no") {
                            await _OthersSymptomsDetect.SetAsync (turnContext, "false", cancellationToken);
                            await _userState.SaveChangesAsync (turnContext, false, cancellationToken);
                        }
                        var otherSymDetect1 = await _OthersSymptomsDetect.GetAsync (turnContext);
                        //Asymptomatic
                        if (covidSymDetect == "false" && otherSymDetect1 == "false") {
                            await turnContext.SendActivityAsync (initialMsg + "\n\n" +
                                "• Testing is not recommended at this time \n\n" +
                                "• You may be asked to wear a mask \n\n" +
                                "• Practice social distancing", null, null, cancellationToken);
                            //flow.LastQuestionAsked = ConversationFlow.Question.PlanVolunteer;
                            await CleanFunc (turnContext, cancellationToken);
                            break;

                        }
                        //symptomatic
                        else {
                            profile.OthersSymptomsDetect = textO;
                            var msgT = "In the last 2 weeks, have you had International travel";
                            await turnContext.SendActivityAsync (msgT, null, null, cancellationToken);
                            flow.LastQuestionAsked = ConversationFlow.Question.TravelInternational;
                            break;
                        }
                    } else {
                        await turnContext.SendActivityAsync (message, null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.OthersSymptomsDetect;
                        break;
                    }
                case ConversationFlow.Question.TravelInternational:
                    if (ValidateYes (input, out var textT, out message)) {
                        profile.TravelInternational = textT;
                        await turnContext.SendActivityAsync ("In the last 2 weeks, have you had Contact with a COVID-19+ person", null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.ContactWithPerson;
                        break;
                    } else {
                        await turnContext.SendActivityAsync (message, null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.TravelInternational;
                        break;
                    }

                case ConversationFlow.Question.ContactWithPerson:
                    if (ValidateYes (input, out var textCont, out message)) {
                        profile.ContactWithPerson = textCont;
                        await turnContext.SendActivityAsync ("In the last 2 weeks, have you had live in or have visited a place where COVID-19 is widespread", null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.LiveInWideSpread;
                        break;
                    } else {
                        await turnContext.SendActivityAsync (message, null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.ContactWithPerson;
                        break;
                    }
                case ConversationFlow.Question.LiveInWideSpread:
                    if (ValidateYes (input, out var textW, out message)) {
                        profile.LiveInWideSpread = textW;
                        await turnContext.SendActivityAsync ("Do you live in a nursing home, assisted living or long-term care facility ? ", null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.LiveInNurseHome;
                        break;
                    } else {
                        await turnContext.SendActivityAsync (message, null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.LiveInWideSpread;
                        break;
                    }
                case ConversationFlow.Question.LiveInNurseHome:
                    if (ValidateYes (input, out var textN, out message)) {
                        if (textN == "no") {
                            profile.LiveInNurseHome = textN;
                            await turnContext.SendActivityAsync ("Do you currently or plan to within the next 2 weeks, work or volunteer in a healthcare facility ? ", null, null, cancellationToken);
                            flow.LastQuestionAsked = ConversationFlow.Question.PlanVolunteer;
                            break;
                        } else if (textN == "yes") {
                            await turnContext.SendActivityAsync ("As per your screening, Bot suggested you to take the following precautions\n\n" +
                                "• Contact your facility\n\n" +
                                "• Self isolate\n\n" +
                                "• Contact your provider if symptoms worsen");
                            await CleanFunc (turnContext, cancellationToken);
                            break;
                        }
                        break;
                    } else {
                        await turnContext.SendActivityAsync (message, null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.LiveInNurseHome;
                        break;
                    }

                case ConversationFlow.Question.PlanVolunteer:
                    if (ValidateYes (input, out var textV, out message)) {
                        if (textV == "no") {
                            profile.PlanVolunteer = textV;
                            var msgV = "Do you have any of the following conditions?\n\n" +
                                "• Chronic lung disease or moderate to severe asthma \n\n" +
                                "• Congestive heart failure \n\n" +
                                "• Diabetes with complications \n\n" +
                                "• Neurologic conditions that weaken ability to cough \n\n" +
                                "• People with weakened immune systems \n\n" +
                                "• Dialysis \n\n" +
                                "• Cirrhosis of the liver \n\n" +
                                "• Pregnancy \n\n" +
                                "• Extreme obesity (BMI ≥ 40) \n\n";
                            await turnContext.SendActivityAsync (msgV, null, null, cancellationToken);
                            flow.LastQuestionAsked = ConversationFlow.Question.Conditions;
                            break;
                        } else if (textV == "yes") {
                            await turnContext.SendActivityAsync ("As per your screening, Bot suggested you to take the following precautions \n\n" +
                                "• Testing recommended \n\n" +
                                "• Contact your occupational health \n\n" +
                                "• Contact your provider if symptoms worsen \n\n" +
                                "• Self isolate");
                            await CleanFunc (turnContext, cancellationToken);
                            break;
                        }
                        break;
                    } else {
                        await turnContext.SendActivityAsync (message, null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.PlanVolunteer;
                        break;
                    }

                case ConversationFlow.Question.Conditions:
                    if (ValidateYes (input, out var textCondition, out message)) {
                        if (textCondition == "yes" && age_detect > 18 && (covidSymDetect == "true" || otherSymDetect == "true")) {
                            var M1 = initialMsg + "\n\n • " + Msg8 + "\n\n • " + Msg3 + "\n\n • " + Msg2;
                            await turnContext.SendActivityAsync (M1);
                            await CleanFunc (turnContext, cancellationToken);
                            break;
                        }
                        if (textCondition == "no" && age_detect >= 65 && covidSymDetect == "true" && (otherSymDetect == "false" || otherSymDetect == "true")) {
                            await turnContext.SendActivityAsync (initialMsg + "\n\n • " + Msg8 + "\n\n •" + Msg3 + "\n\n • " + Msg2);
                            await CleanFunc (turnContext, cancellationToken);
                            break;
                        }
                        if (textCondition == "no" && age_detect >= 65 && otherSymDetect == "true" && covidSymDetect == "false") {
                            await turnContext.SendActivityAsync (initialMsg + "\n\n • " + Msg8 + "\n\n • " + Msg2);
                            await CleanFunc (turnContext, cancellationToken);
                            break;
                        }

                        if (textCondition == "no" && age_detect < 65 && otherSymDetect == "true" && covidSymDetect == "false") {
                            await turnContext.SendActivityAsync (initialMsg + "\n\n • " + Msg8 + "\n\n • " + Msg1 + "\n\n • " + Msg2);
                            await CleanFunc (turnContext, cancellationToken);
                            break;
                        }
                        if (textCondition == "no" && age_detect < 65 && covidSymDetect == "true" && (otherSymDetect == "false" || otherSymDetect == "true")) {
                            await turnContext.SendActivityAsync (initialMsg + "\n\n • " + Msg8 + "\n\n • " + Msg2);
                            await CleanFunc (turnContext, cancellationToken);
                            break;
                        } else {
                            await turnContext.SendActivityAsync (initialMsg + "\n\n • " + Msg8 + "\n\n • " + Msg2);
                            await CleanFunc (turnContext, cancellationToken);
                            break;
                        }

                        //break;

                    } else {
                        await turnContext.SendActivityAsync (message, null, null, cancellationToken);
                        flow.LastQuestionAsked = ConversationFlow.Question.PlanVolunteer;
                        await CleanFunc (turnContext, cancellationToken);
                        break;
                    }

            }
        }

        private async Task CleanFunc (ITurnContext turnContext, CancellationToken cancellationToken) {
            await _SymptomsScreeningStage.SetAsync (turnContext, null, cancellationToken);
            await _AgeDetect.SetAsync (turnContext, 0, cancellationToken);
            await _CovidSymptomsDetect.SetAsync (turnContext, null, cancellationToken);
            await _OthersSymptomsDetect.SetAsync (turnContext, null, cancellationToken);
            await _conversationStateAccessors.SetAsync (turnContext, null, cancellationToken);
            //await _conversationState.SetAsync(turnContext, null, cancellationToken);
            await _userState.SaveChangesAsync (turnContext, false, cancellationToken);
        }
        private static bool ValidateYes (string input, out string text, out string message) {
            text = null;
            message = null;
            input = input.ToLower ().Trim ();
            if ((input != "yes" && input != "no") || (input != "no" && input != "yes")) //string.IsNullOrWhiteSpace(input) &&
            {
                message = "Please enter a yes or no for continue...";
            } else {
                text = input.Trim ();
            }

            return message is null;
        }

        private static bool ValidateAge (string input, out int text, out string message) {
            text = 0;
            message = null;
            //var age = Convert.ToInt16(input.Trim());
            int age;
            if (int.TryParse (input, out age))
            //if (age != 0) //string.IsNullOrWhiteSpace(input) &&
            {
                text = age;
            } else {

                message = "Please enter a age in number.";
            }

            return message is null;
        }
    }
}