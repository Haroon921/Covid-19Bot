using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Integration.AspNet.Core;
using Microsoft.BotBuilderSamples.Translation;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Bot.Connector.Authentication;
// using Microsoft.AspNetCore.Mvc;


using Microsoft.Bot.Builder.BotFramework;


namespace Microsoft.BotBuilderSamples {
    public class Startup {
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices (IServiceCollection services) {

            // services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            services.AddControllers ().AddNewtonsoftJson ();

            // Create the Bot Framework Adapter with error handling enabled.
            services.AddSingleton<IBotFrameworkHttpAdapter, AdapterWithErrorHandler> ();


            // Create the bot services (LUIS, QnA) as a singleton.
            services.AddSingleton<IBotServices, BotServices> ();

           

            // Create the User state. (Used to store the user's language preference.)
            // var storage = new MemoryStorage();

            // var userState = new UserState(storage);
            // services.AddSingleton(userState);
            services.AddSingleton<IStorage, MemoryStorage>();
            
            services.AddSingleton<UserState>();

            // Create the Conversation state.
            services.AddSingleton<ConversationState>();
            
            // Create the Microsoft Translator responsible for making calls to the Cognitive Services translation service
            //services.AddSingleton<MicrosoftTranslator> ();
            services.AddSingleton<BotServices>();
            // Create the Translation Middleware that will be added to the middleware pipeline in the AdapterWithErrorHandler
            services.AddSingleton<TranslationMiddleware> ();

            // Create the credential provider to be used with the Bot Framework Adapter.
            services.AddSingleton<ICredentialProvider, ConfigurationCredentialProvider>();

           
            // Create the bot as a transient.
            services.AddTransient<IBot, DispatchBot>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure (IApplicationBuilder app, IWebHostEnvironment env) {
            if (env.IsDevelopment ()) {
                app.UseDeveloperExceptionPage ();
            }

            app.UseDefaultFiles ()
                .UseStaticFiles ()
                .UseRouting ()
                .UseAuthorization ()
                .UseEndpoints (endpoints => {
                    endpoints.MapControllers ();
                });

        }
    }
}